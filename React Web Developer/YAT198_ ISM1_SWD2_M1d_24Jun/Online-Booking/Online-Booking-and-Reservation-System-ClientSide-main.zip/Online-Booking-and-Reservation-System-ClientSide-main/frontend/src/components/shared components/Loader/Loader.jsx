import './Loader.css';
function Loader (){
    return(
        <div className='loader-container'>
            <p className="loader"></p>
        </div>

    );
}
export default Loader;