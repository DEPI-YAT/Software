import './Profile.css';

function Profile() {
    return (
        <div className="profile-container">
            <h1>Admin Profile</h1>
           
        </div>
    );
}

export default Profile;
